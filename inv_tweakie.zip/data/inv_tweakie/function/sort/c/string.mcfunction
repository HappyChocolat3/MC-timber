execute in minecraft:overworld if items block 1 -64 0 container.0 minecraft:string run return 1
return 0
